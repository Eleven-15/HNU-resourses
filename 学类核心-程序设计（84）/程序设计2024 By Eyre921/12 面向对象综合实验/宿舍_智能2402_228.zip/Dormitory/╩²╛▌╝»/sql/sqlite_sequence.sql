create table sqlite_sequence
(
    name,
    seq
);

INSERT INTO sqlite_sequence (name, seq) VALUES ('dormitories', 9);
INSERT INTO sqlite_sequence (name, seq) VALUES ('rooms', 22);
INSERT INTO sqlite_sequence (name, seq) VALUES ('accommodation_requests', 15);
INSERT INTO sqlite_sequence (name, seq) VALUES ('check_in_out_records', 26);
INSERT INTO sqlite_sequence (name, seq) VALUES ('repair_requests', 12);
