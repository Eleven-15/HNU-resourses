# include "vehicle.h"
# include "vehicleLink.h"

int vehicleNode::cnt=0;
vehicleNode* vehicleNode::head=new vehicleNode;

vehicleNode::vehicleNode()
{
    next=NULL;
}
vehicleNode::vehicleNode(vehicle *myVehicle)
{
    s=myVehicle;
    next=NULL;
    cnt++;
}
vehicleNode::~vehicleNode()
{
    while(head != NULL)
    {
        vehicleNode *p=head;
        head=head->next;
        delete p;
    }
}
bool vehicleNode::operator<(const vehicleNode& another) const
{
    return s->sumMile()<another.s->sumMile();
}

void vehicleNode::insertNode(vehicle *newVehicle)
{
    vehicleNode *newNode=new vehicleNode(newVehicle),*p=head;
    while(p->next != NULL)
        p=p->next;

    p->next=newNode;
}
void vehicleNode::show()
{
    vehicleNode *p=head->next;
    while(p!=NULL)
    {
        p->s->out();
        p=p->next;
    }
}
void vehicleNode::sortL()
{
    vehicleNode *p;
    for(int i=1; i<=cnt-1; i++)
    {
        p=head->next;
        for(int j=1; j<=cnt-i; j++)
        {
            if (*p< *(p->next))
            {
                vehicle *tmp=p->s;
                p->s=p->next->s;
                p->next->s=tmp;
            }
            p=p->next;
        }
     }
}
