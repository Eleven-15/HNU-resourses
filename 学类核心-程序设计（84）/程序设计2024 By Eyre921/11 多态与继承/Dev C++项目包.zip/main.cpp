#include <iostream>
#include "factory.h"
#include "vehicle.h"
#include "vehicleLink.h"

using namespace std;

int main()
{
    abstractFactory *myCarFactory=new carFactory();
    abstractFactory *myMotorFactory=new motorFactory();
    vehicle *newVehicle;
    int sel=1;
    while(cin>>sel)
    {
        switch(sel)
        {
        case 1:
            newVehicle=myCarFactory->BuildVehicle(1);
            break;
        case 2:
            newVehicle=myCarFactory->BuildVehicle(2);
            break;
        case 3:
            newVehicle=myCarFactory->BuildVehicle(3);
            break;
        case 4:
            newVehicle=myMotorFactory->BuildVehicle();
            break;
        }
        newVehicle->in();
        vehicleNode::insertNode(newVehicle);
    }

    vehicleNode::sortL();
    vehicleNode::show();

    return 0;
}
