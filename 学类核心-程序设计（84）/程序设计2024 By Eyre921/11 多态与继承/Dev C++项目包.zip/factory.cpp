# include "factory.h"
# include "vehicle.h"
car* carFactory::BuildVehicle(int style)
{
    car *newCar;
    if (style==1)
        newCar=new gasCar();
    else if (style==2)
        newCar=new electricCar();
    else
        newCar=new mixCar();

    return newCar;
}
motor* motorFactory::BuildVehicle(int style)
{
    return new motor();
}
