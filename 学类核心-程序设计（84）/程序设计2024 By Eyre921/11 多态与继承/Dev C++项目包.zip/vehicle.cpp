# include "vehicle.h"
void gasCar::in()
{
   std::cin>>brand>>power>>mile;
}
void gasCar::out()
{
    std::cout<<"Gas Car: ";
    std::cout<<"[Brand-"<<brand<<" "<<"Oil Box-"<<power<<" "<<"Mile-"<<mile<<"]"<<std::endl<<std::endl;

}

int gasCar::sumMile()
{
    return mile;
}

void electricCar::in()
{
    std::cin>>brand>>battery>>emile;
}
void electricCar::out()
{
    std::cout<<"Electric Car: ";
    std::cout<<"[Brand-"<<brand<<" "<<"Battery-"<<battery<<" "<<"eMile-"<<emile<<"]"<<std::endl;
    std::cout<<std::endl;

}
int electricCar::sumMile()
{
    return emile;
}

void mixCar::in()
{
    std::cin>>brand>>power>>mile>>battery>>emile;
}
void mixCar::out()
{
    std::cout<<"Mix Energy Car: ";
    std::cout<<"[Brand-"<<brand<<" "<<"Oil Box-"<<power<<" "<<"Mile-"<<mile<<" "<<"Battery-"<<battery<<" "<<"eMile-"<<emile<<"]"<<std::endl;
    std::cout<<std::endl;
}
int mixCar::sumMile()
{
    return mile+emile;
}

void motor::in()
{
    std::cin>>brand>>wheels>>mile;
}
void motor::out()
{
    std::cout<<wheels<<"-Wheels Motor: ";
    std::cout<<"[Brand-"<<brand<<" "<<"Mile-"<<mile<<"]"<<std::endl<<std::endl;;
}

int motor::sumMile()
{
    return mile;
}
