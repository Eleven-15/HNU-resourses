#ifndef FACTORY_INCLUDED
#define FACTORY_INCLUDED
# include "factory.h"
# include "vehicle.h"
class abstractFactory
{
    public:
    virtual vehicle* BuildVehicle(int style=0) = 0;
};
class carFactory:public abstractFactory
{
public:
    car *BuildVehicle(int style=0);
};

class motorFactory:public abstractFactory
{
public:

    motor *BuildVehicle(int style=0);
};
#endif
