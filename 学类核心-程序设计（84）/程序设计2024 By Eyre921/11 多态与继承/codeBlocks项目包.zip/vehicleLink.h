#ifndef VEHICLELINK_H_INCLUDED
#define VEHICLELINK_H_INCLUDED
#include "vehicle.h"
class vehicleNode
{
public:
    vehicleNode();
    vehicleNode(vehicle *myVehicle);
    ~vehicleNode();
    static int cnt;
    static vehicleNode *head;
    static void insertNode(vehicle *newVehicle);
    static void show();
    static void sortL();

private:
    vehicle *s;
    vehicleNode *next;
    bool operator<(const vehicleNode& another) const;
};
#endif // VEHICLELINK_H_INCLUDED
